﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            // Cấu hình DataGridView
            dataGridView1.ColumnCount = 3;
            dataGridView1.Columns[0].Name = "ID";
            dataGridView1.Columns[1].Name = "Tên";
            dataGridView1.Columns[2].Name = "Tuổi";
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btn_id_Click(object sender, EventArgs e)
        {

        }

        private void btn_them_Click(object sender, EventArgs e)
        {
            // Mở Form2 khi nhấn "Thêm"
            Form2 form2 = new Form2();

            // Gán delegate của Form2 để nhận dữ liệu và thêm vào DataGridView của Form1
            form2.UpdateDataDelegate = AddRowToDataGridView;

            // Hiển thị Form2
            form2.ShowDialog();
        }

        private void btn_xoa_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                foreach (DataGridViewRow row in dataGridView1.SelectedRows)
                {
                    dataGridView1.Rows.Remove(row);
                }
            }
            else
            {
                MessageBox.Show("Vui lòng chọn một hàng để xóa!");
            }
        }

        private void btn_sua_Click(object sender, EventArgs e)
        {

        }
        private void AddRowToDataGridView(string id, string name, string age)
        {
            dataGridView1.Rows.Add(id, name, age);
        }

        private void UpdateSelectedRowInDataGridView(string id, string name, string age)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];
                selectedRow.Cells[0].Value = id;
                selectedRow.Cells[1].Value = name;
                selectedRow.Cells[2].Value = age;
            }
        }
    }
}
