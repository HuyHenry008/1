﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form2 : Form
    {
        internal Action<string, string, string> UpdateDataDelegate;

        public Form2()
        {
            InitializeComponent();
        }
        private void btn_luu_Click(object sender, EventArgs e)
        {
            // Validate if the TextBoxes are not empty
            if (string.IsNullOrWhiteSpace(txt_id.Text) ||
                string.IsNullOrWhiteSpace(txt_ten.Text) ||
                string.IsNullOrWhiteSpace(txt_tuoi.Text))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ thông tin!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Call the delegate and pass data to Form1
            UpdateDataDelegate?.Invoke(txt_id.Text, txt_ten.Text, txt_tuoi.Text);

            // Close Form2 after saving data
            this.Close();
        }

        private void txt_id_TextChanged(object sender, EventArgs e) { }
        private void txt_ten_TextChanged(object sender, EventArgs e) { }
        private void txt_tuoi_TextChanged(object sender, EventArgs e) { }

        private void btn_xacnhan_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txt_id.Text) ||
                  string.IsNullOrWhiteSpace(txt_ten.Text) ||
                  string.IsNullOrWhiteSpace(txt_tuoi.Text))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ thông tin!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Assuming UpdateDataDelegate is set from Form1
            UpdateDataDelegate?.Invoke(txt_id.Text, txt_ten.Text, txt_tuoi.Text);

            // Optionally, you can show a confirmation message after the data is saved
            MessageBox.Show("Dữ liệu đã được xác nhận!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);

            // Close the form after confirmation
            this.Close();
        }

        private void btn_thoat_Click(object sender, EventArgs e)
        {
            // Close the form when the user clicks 'Thoat' (Exit)
            this.Close();
        }
    }
}

